module app {
    requires collegeinfo;
}